/* Placeholder for an ultrasonic sensor class */

#include "Smartcar.h"

UltrasonicSensor::UltrasonicSensor(){}
