/* Placeholder for an generic motor class */

#include "Smartcar.h"

Motor::Motor(){}

Motor::~Motor(){}

void Motor::init(){}
