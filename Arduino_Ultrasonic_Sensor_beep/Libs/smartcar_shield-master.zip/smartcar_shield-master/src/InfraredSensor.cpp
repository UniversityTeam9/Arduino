/* Placeholder for an infrared sensor class */

#include "Smartcar.h"

InfraredSensor::InfraredSensor(){}
