# 2D CAD files
You can use or edit these files, in order to fabricate your own Smartcar chassis.

### Formats
* *.dxf
* *.dwg

### Preview
![smartcar chassis](http://i.imgur.com/mM6PAL9.png)

### License
CC BY-SA 4.0
